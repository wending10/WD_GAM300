using ScriptAPI;
using System;

public class NewBehaviourScript : Script 
{ 
	public override void Awake()
	{

	}
	public override void Update()
	{

	}
 }