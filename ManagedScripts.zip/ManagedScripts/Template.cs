using ScriptAPI;
using System;

public class Template : Script
{
    public override void Awake()
    {

    }
    public override void OnEnable()
    {

    }
    public override void Start()
    {
        
    }
    public override void Update()
    {
        
    }
    public override void LateUpdate()
    {

    }
    public override void OnDisable()
    {

    }
    public override void OnDestroy()
    {
        
    }
}