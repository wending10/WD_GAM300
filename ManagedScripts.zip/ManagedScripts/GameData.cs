﻿using System;

public class GameData
{
    public bool _LockpickTutorialDone;
    public bool _FlashlightTutorialDone;
    public bool _InventoryTutorialDone;
    public bool _HidingTutorialDone;
}
